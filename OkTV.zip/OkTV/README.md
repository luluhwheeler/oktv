# OkTV — media player de ok.ru para Android TV
Abrir no Android Studio (Hedgehog+), sincronizar Gradle, rodar em emulador/TV Android.

Funções: busca, colar link/ID, canais/playlists salvos, favoritos, histórico, retomar de onde parou,
qualidade (HLS auto / MP4 por resolução), velocidade, seek ±10s no D-pad, próximo/anterior (CH+/CH-),
autoplay da playlist, sleep timer, deep link ok.ru.

Obs.: usa scraping da página pública (data-options); se o ok.ru mudar o HTML, ajuste OkRu.kt.
Sem API oficial: respeite os Termos de Uso do ok.ru e direitos autorais.

## Gerar o APK
- Android Studio: Build > Build APK(s), ou
- GitHub: suba esta pasta num repositório; a aba Actions gera o `app-debug.apk` (workflow incluso).
- Instalar na TV: `adb connect IP_DA_TV && adb install app-debug.apk`
