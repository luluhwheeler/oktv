package com.oktv

import android.view.KeyEvent
import android.view.ViewGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

@Composable
fun PlayerScreen(video: VideoItem, queue: List<VideoItem>, store: Store, onClose: () -> Unit, onNext: (VideoItem) -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var stream by remember { mutableStateOf<Stream?>(null) }
    var failed by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(true) }
    var speedIdx by remember { mutableStateOf(2) }
    var qualityIdx by remember { mutableStateOf(-1) } // -1 = HLS automático
    var fav by remember { mutableStateOf(store.isFavorite(video.id)) }
    var sleepMin by remember { mutableStateOf(0) }
    var autoplay by remember { mutableStateOf(true) }
    val focus = remember { FocusRequester() }

    fun nextInQueue(step: Int): VideoItem? {
        val i = queue.indexOfFirst { it.id == video.id }
        return if (i >= 0) queue.getOrNull(i + step) else null
    }

    LaunchedEffect(video.id) {
        failed = false
        stream = runCatching { OkRu.resolve(video.id) }.getOrNull()
        if (stream == null) failed = true
    }
    LaunchedEffect(stream, qualityIdx) {
        val s = stream ?: return@LaunchedEffect
        val pos = if (player.currentPosition > 0) player.currentPosition else store.position(video.id)
        val url = if (qualityIdx >= 0) s.qualities.getOrNull(qualityIdx)?.second else s.hls ?: s.qualities.firstOrNull()?.second
        if (url == null) { failed = true; return@LaunchedEffect }
        player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.seekTo(pos); player.playWhenReady = true
        player.setPlaybackSpeed(SPEEDS[speedIdx])
    }
    LaunchedEffect(Unit) { while (true) { delay(5000); if (player.isPlaying) store.savePosition(video.id, player.currentPosition) } }
    LaunchedEffect(showMenu) { if (showMenu) { delay(5000); showMenu = false } }
    LaunchedEffect(sleepMin) { if (sleepMin > 0) { delay(sleepMin * 60_000L); player.pause(); onClose() } }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) { store.savePosition(video.id, 0); if (autoplay) nextInQueue(1)?.let(onNext) }
            }
        }
        player.addListener(l)
        onDispose { store.savePosition(video.id, player.currentPosition); player.removeListener(l); player.release() }
    }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Box(Modifier.fillMaxSize().focusRequester(focus).focusable().onPreviewKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        when (e.nativeKeyEvent.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)); true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { player.seekTo(player.currentPosition + 10_000); true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { if (player.isPlaying) player.pause() else player.play(); showMenu = true; true }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> { showMenu = true; true }
            KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_CHANNEL_UP -> { nextInQueue(1)?.let(onNext); true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_CHANNEL_DOWN -> { nextInQueue(-1)?.let(onNext); true }
            else -> false
        }
    }) {
        AndroidView(factory = { PlayerView(it).apply {
            this.player = player; useController = true; controllerShowTimeoutMs = 4000
            layoutParams = ViewGroup.LayoutParams(-1, -1); isFocusable = false } }, modifier = Modifier.fillMaxSize())
        if (failed) Text("Não foi possível carregar o vídeo.", Modifier.align(Alignment.Center))
        if (showMenu) Row(Modifier.align(Alignment.TopStart).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip({ speedIdx = (speedIdx + 1) % SPEEDS.size; player.setPlaybackSpeed(SPEEDS[speedIdx]) }, { Text("${SPEEDS[speedIdx]}x") })
            AssistChip({
                val n = stream?.qualities?.size ?: 0
                qualityIdx = if (qualityIdx + 1 >= n) -1 else qualityIdx + 1
            }, { Text(if (qualityIdx < 0) "Qualidade: Auto" else "Qualidade: ${stream?.qualities?.getOrNull(qualityIdx)?.first}") })
            AssistChip({ fav = store.toggleFavorite(video) }, { Text(if (fav) "★ Favorito" else "☆ Favoritar") })
            AssistChip({ autoplay = !autoplay }, { Text("Autoplay: ${if (autoplay) "on" else "off"}") })
            AssistChip({ sleepMin = when (sleepMin) { 0 -> 15; 15 -> 30; 30 -> 60; else -> 0 } }, { Text(if (sleepMin == 0) "Sleep: off" else "Sleep: ${sleepMin}min") })
        }
    }
}
