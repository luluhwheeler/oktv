package com.oktv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.jsoup.Jsoup

data class VideoItem(val id: String, val title: String, val thumb: String, val url: String)
data class Stream(val title: String, val hls: String?, val qualities: List<Pair<String, String>>)

object OkRu {
    private val http = OkHttpClient()
    private const val UA = "Mozilla/5.0 (Linux; Android 11; TV) AppleWebKit/537.36 Chrome/120 Safari/537.36"

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", UA).header("Accept-Language", "pt-BR,en").build()
        http.newCall(req).execute().use { it.body?.string().orEmpty() }
    }

    /** Extrai ID de qualquer link ok.ru/video/ID, ok.ru/videoembed/ID ou id puro. */
    fun videoId(input: String): String? =
        Regex("""(?:video|videoembed)/(\d+)""").find(input)?.groupValues?.get(1)
            ?: input.trim().takeIf { it.matches(Regex("\\d{6,}")) }

    /** Resolve as URLs reproduzíveis (HLS + MP4 por qualidade) de um vídeo. */
    suspend fun resolve(id: String): Stream? {
        val html = get("https://ok.ru/video/$id")
        val opts = Jsoup.parse(html).select("[data-options]").firstOrNull()?.attr("data-options") ?: return null
        val meta = JSONObject(opts).optJSONObject("flashvars")?.optString("metadata") ?: return null
        val m = JSONObject(meta)
        val order = listOf("ultra", "quad", "full", "hd", "sd", "low", "lowest", "mobile")
        val arr = m.optJSONArray("videos")
        val q = buildList {
            if (arr != null) for (i in 0 until arr.length()) add(arr.getJSONObject(i).let { it.getString("name") to it.getString("url") })
        }.sortedBy { order.indexOf(it.first).let { i -> if (i < 0) 99 else i } }
        val hls = listOf("hlsMasterPlaylistUrl", "hlsManifestUrl", "ondemandHls").map { m.optString(it) }.firstOrNull { it.isNotBlank() }
        return Stream(m.optJSONObject("movie")?.optString("title").orEmpty(), hls, q)
    }

    /** Lista vídeos de uma página: busca, canal, playlist ou perfil. */
    suspend fun list(pageUrl: String): List<VideoItem> {
        val doc = Jsoup.parse(get(pageUrl), "https://ok.ru")
        return doc.select("a[href*=/video/]").mapNotNull { a ->
            val id = videoId(a.attr("href")) ?: return@mapNotNull null
            val img = a.selectFirst("img")
            val title = (a.attr("title").ifBlank { img?.attr("alt").orEmpty() }).ifBlank { a.text() }
            VideoItem(id, title.ifBlank { "Vídeo $id" }, img?.absUrl("src").orEmpty(), "https://ok.ru/video/$id")
        }.distinctBy { it.id }
    }

    fun searchUrl(q: String) = "https://ok.ru/video/search?st.query=" + java.net.URLEncoder.encode(q, "UTF-8")
}
