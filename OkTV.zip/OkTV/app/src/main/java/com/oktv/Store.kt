package com.oktv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Favoritos, histórico, posições de retomada e canais/playlists salvos. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("oktv", Context.MODE_PRIVATE)

    fun position(id: String) = sp.getLong("pos_$id", 0L)
    fun savePosition(id: String, ms: Long) = sp.edit().putLong("pos_$id", ms).apply()

    private fun readList(key: String): MutableList<VideoItem> {
        val a = JSONArray(sp.getString(key, "[]"))
        return MutableList(a.length()) { i -> a.getJSONObject(i).let { VideoItem(it.getString("id"), it.getString("t"), it.getString("th"), it.getString("u")) } }
    }
    private fun writeList(key: String, l: List<VideoItem>) = sp.edit().putString(key,
        JSONArray(l.map { JSONObject().put("id", it.id).put("t", it.title).put("th", it.thumb).put("u", it.url) }).toString()).apply()

    fun favorites() = readList("fav")
    fun toggleFavorite(v: VideoItem): Boolean {
        val l = readList("fav"); val had = l.removeAll { it.id == v.id }
        if (!had) l.add(0, v); writeList("fav", l); return !had
    }
    fun isFavorite(id: String) = readList("fav").any { it.id == id }

    fun history() = readList("hist")
    fun addHistory(v: VideoItem) { val l = readList("hist"); l.removeAll { it.id == v.id }; l.add(0, v); writeList("hist", l.take(100)) }

    /** Canais/playlists salvos: nome -> URL (ex.: https://ok.ru/video/c123456 ou https://ok.ru/profile/ID/video) */
    fun sources(): MutableList<Pair<String, String>> {
        val a = JSONArray(sp.getString("src", "[]"))
        return MutableList(a.length()) { i -> a.getJSONObject(i).let { it.getString("n") to it.getString("u") } }
    }
    fun addSource(name: String, url: String) {
        val l = sources(); l.removeAll { it.second == url }; l.add(name to url)
        sp.edit().putString("src", JSONArray(l.map { JSONObject().put("n", it.first).put("u", it.second) }).toString()).apply()
    }
    fun removeSource(url: String) {
        val l = sources(); l.removeAll { it.second == url }
        sp.edit().putString("src", JSONArray(l.map { JSONObject().put("n", it.first).put("u", it.second) }).toString()).apply()
    }
}
