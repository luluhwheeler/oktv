package com.oktv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val deepLink = intent?.data?.toString()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { App(deepLink) } } }
    }
}

@Composable
fun App(deepLink: String?) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var items by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var queue by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var playing by remember { mutableStateOf<VideoItem?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val tabs = listOf("Buscar", "Canais/Playlists", "Favoritos", "Histórico")

    fun load(url: String) = scope.launch {
        loading = true; error = null
        runCatching { OkRu.list(url) }.onSuccess { items = it; if (it.isEmpty()) error = "Nada encontrado" }
            .onFailure { error = "Erro: ${it.message}" }
        loading = false
    }
    fun open(v: VideoItem, list: List<VideoItem>) { queue = list; playing = v; store.addHistory(v) }

    LaunchedEffect(deepLink) {
        deepLink?.let { link -> OkRu.videoId(link)?.let { id -> open(VideoItem(id, "Vídeo $id", "", link), emptyList()) } }
    }

    playing?.let { v ->
        BackHandler { playing = null }
        PlayerScreen(v, queue, store, onClose = { playing = null }, onNext = { n -> playing = n; store.addHistory(n) })
        return
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("OkTV", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tabs.forEachIndexed { i, t -> FilterChip(selected = tab == i, onClick = { tab = i; items = emptyList(); error = null
                if (i == 2) items = store.favorites(); if (i == 3) items = store.history() }, label = { Text(t) }) }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            0 -> OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Pesquisar ou colar link/ID de vídeo, canal ou playlist") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    val q = query.trim()
                    val id = OkRu.videoId(q)
                    when {
                        id != null -> open(VideoItem(id, "Vídeo $id", "", "https://ok.ru/video/$id"), emptyList())
                        q.startsWith("http") -> load(q)
                        else -> load(OkRu.searchUrl(q))
                    }
                }))
            1 -> SourcesTab(store, onOpen = { load(it) })
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        LazyVerticalGrid(GridCells.Adaptive(220.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(top = 12.dp)) {
            items(items) { v ->
                Card(onClick = { open(v, items) }) {
                    Column {
                        AsyncImage(v.thumb, null, Modifier.fillMaxWidth().height(124.dp).clip(MaterialTheme.shapes.medium), contentScale = ContentScale.Crop)
                        Text(v.title, Modifier.padding(8.dp), maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun SourcesTab(store: Store, onOpen: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var list by remember { mutableStateOf(store.sources().toList()) }
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true, label = { Text("Nome") })
            OutlinedTextField(url, { url = it }, Modifier.weight(2f), singleLine = true, label = { Text("URL do canal/playlist (ok.ru/video/c123…)") })
            Button(onClick = { if (url.isNotBlank()) { store.addSource(name.ifBlank { url }, url.trim()); list = store.sources().toList(); name = ""; url = "" } }) { Text("Salvar") }
        }
        LazyColumn(Modifier.heightIn(max = 160.dp)) {
            items(list) { (n, u) ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onOpen(u) }) { Text(n) }
                    OutlinedButton(onClick = { store.removeSource(u); list = store.sources().toList() }) { Text("Remover") }
                }
            }
        }
    }
}
